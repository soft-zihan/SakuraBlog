<script setup lang="ts">

</script>

<template>
  班级管理
</template>

<style scoped>

</style>