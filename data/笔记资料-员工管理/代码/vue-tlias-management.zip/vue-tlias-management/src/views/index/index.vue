<script setup lang="ts">

</script>

<template>
  <!-- <img src="../../assets/index.png"> -->
  <img src="@/assets/index.png">
</template>

<style scoped>

</style>