<script setup lang="ts">
// import Layout from './views/layout/index.vue'

</script>

<template>
  <!-- <Layout></Layout> -->
  <!-- 动态路由组件 -->
  <RouterView></RouterView>
</template>

<style scoped>

</style>
