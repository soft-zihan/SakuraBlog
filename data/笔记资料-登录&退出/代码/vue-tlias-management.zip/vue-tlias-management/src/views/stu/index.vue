<script setup lang="ts">

</script>

<template>
  学员管理
</template>

<style scoped>

</style>