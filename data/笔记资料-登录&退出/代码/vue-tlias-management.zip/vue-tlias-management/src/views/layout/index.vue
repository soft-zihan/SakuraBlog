<script setup lang="ts">
// 导入路由对象
import router from '@/router';
// 导入Store对象
import {useLoginEmpStore} from '@/stores/loginEmp'
import { ElMessage } from 'element-plus';

import { ref } from 'vue';

// 使用Store
const store = useLoginEmpStore()

// 登录人
const loginName = ref<string|undefined>('')
loginName.value = store.loginEmp.name;


// 退出登录
const logout = () => {
    // 1.清除store中的登录信息
    store.removeLoginEmp();

    // 2.跳转到登录页面
    router.push('/login');
    ElMessage.success('退出成功');
}
</script>

<template>
    <div class="common-layout">
        <el-container>
            <!-- 顶栏 -->
            <el-header class="header">
                <span class="title"><b>Tlias智能学习辅助系统</b></span>
                <span class="right_tool">
                    <a href=""><el-icon><EditPen /></el-icon>修改密码&nbsp;&nbsp;|&nbsp;&nbsp;</a>
                    <a href="" @click="logout"><el-icon><SwitchButton /></el-icon>退出登录【{{loginName}}】</a>
                </span>
            </el-header>

            <el-container>
                <!-- 左侧菜单 -->
                <el-aside width="200px" class="aside">
                <el-scrollbar>
                    <!-- router: 启用 vue-router 模式。 启用该模式会在激活导航时以 index 作为 path 进行路由跳转 使用  -->
                    <el-menu router>
                    <!-- 首页菜单 -->
                    <el-menu-item index="/index">
                        <el-icon><Promotion /></el-icon>首页
                    </el-menu-item>
                    
                    <!-- 班级管理菜单 -->
                    <el-sub-menu index="/manage">
                        <template #title>
                        <el-icon><Menu /></el-icon> 班级学员管理
                        </template>
                        <el-menu-item index="/clazz">
                        <el-icon><HomeFilled /></el-icon>班级管理
                        </el-menu-item>
                        <el-menu-item index="/stu">
                        <el-icon><UserFilled /></el-icon>学员管理
                        </el-menu-item>
                    </el-sub-menu>
                    
                    <!-- 系统信息管理 -->
                    <el-sub-menu index="/system">
                        <template #title>
                        <el-icon><Tools /></el-icon>系统信息管理
                        </template>
                        <el-menu-item index="/dept">
                        <el-icon><HelpFilled /></el-icon>部门管理
                        </el-menu-item>
                        <el-menu-item index="/emp">
                        <el-icon><Avatar /></el-icon>员工管理
                        </el-menu-item>
                    </el-sub-menu>

                    <!-- 数据统计管理 -->
                    <el-sub-menu index="/report">
                        <template #title>
                        <el-icon><Histogram /></el-icon>数据统计管理
                        </template>
                        <el-menu-item index="/empReport">
                        <el-icon><InfoFilled /></el-icon>员工信息统计
                        </el-menu-item>
                        <el-menu-item index="/stuReport">
                        <el-icon><Share /></el-icon>学员信息统计
                        </el-menu-item>
                        <el-menu-item index="/log">
                        <el-icon><Document /></el-icon>日志信息统计
                        </el-menu-item>
                    </el-sub-menu>
                    </el-menu>
                </el-scrollbar>
                </el-aside>

                <!-- 主区域 -->
                <el-main>
                    <!-- 动态路由组件 -->
                    <RouterView></RouterView>
                </el-main>
            </el-container>
        </el-container>
    </div>
</template>

<style scoped>
.header {
    /* background-color: rgb(104, 104, 188); */
    background-image: linear-gradient(to right, #6947bf, #8753c9, #a260d2, #bc6edc, #d57de5);
}
.title {
    font-size: 40px;
    color: white;
    font-family: 楷体;
    line-height: 60px;
}
.right_tool {
    float: right;   /* 右侧悬浮 */
    line-height: 60px;
}
a {
    color: white;
    text-decoration: none;
}
.aside {
  width: 220px;
  border: 1px solid #ccc;
  height: 690px;
}
</style>