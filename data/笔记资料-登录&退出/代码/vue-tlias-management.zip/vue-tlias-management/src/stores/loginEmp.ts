import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import type { LoginInfo } from '@/api/model/model'

// Store对象---通过defineStore创建出来----该对象用来管理所有的共享状态（数据+方法）
// 第一个参数：loginEmpInfo，是一个唯一标识
// 第二个参数：是个函数，里面可以定义共享数据、共享方法，注意：最后需要return出所有的数据和方法
// 第三个参数：{persist: true}，声明要持久化
export const useLoginEmpStore = defineStore('loginEmpInfo', () => {
  // 1.定义一个对象，用来存储所有的用户登录信息
  const loginEmp = ref<LoginInfo>({})

  // 2.存储用户登录信息---loginEmp对象数据
  const setLoginEmp = (loginInfo: LoginInfo)=>{
    loginEmp.value = loginInfo;
  }

  // 3.获取用户登录信息---loginEmp对象数据
  const getLoginEmp = () => {
    return loginEmp.value;
  }

  // 4.清除用户登录信息---loginEmp对象数据
  const removeLoginEmp = ()=>{
    loginEmp.value = {}
  }

  return { loginEmp, setLoginEmp, getLoginEmp, removeLoginEmp }
}, {persist: true})
