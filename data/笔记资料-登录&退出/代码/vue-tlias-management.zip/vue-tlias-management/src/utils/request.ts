import axios from 'axios'
import router from '@/router';
// 导入Store对象
import {useLoginEmpStore} from '@/stores/loginEmp'
import { ElMessage } from 'element-plus';

// 使用Store
const store = useLoginEmpStore()

//创建axios实例对象
const request = axios.create({
  baseURL: '/api',
  timeout: 600000
})

// 添加请求拦截器
request.interceptors.request.use(function (config) {
  // 在发送请求之前做些什么
  // 将令牌存入到请求头中
  const loginEmp = store.getLoginEmp();
  if(loginEmp && loginEmp.token){
    config.headers['token'] = loginEmp.token
  }

  return config;
}, function (error) {
  // 对请求错误做些什么
  return Promise.reject(error);
});

//axios的响应 response 拦截器
request.interceptors.response.use(
  (response) => { //成功回调
    return response.data
  },
  (error) => { //失败回调
    if(error.response.status == 401) {
      // 通过路由vue-router进行跳转--跳到登录页面/login
      router.push('/login')
      ElMessage.error('登录失效，请重新登录！')
    }
    return Promise.reject(error)
  }
)

export default request