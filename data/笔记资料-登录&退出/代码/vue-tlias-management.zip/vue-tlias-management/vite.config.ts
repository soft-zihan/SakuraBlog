import { fileURLToPath, URL } from 'node:url'

import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import vueJsx from '@vitejs/plugin-vue-jsx'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [vue(), vueJsx()],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    }
  },
  server: {
    // 配置反向代理
    proxy: {
      // http://127.0.0.1:5173/api/depts---》http://localhost:8080/depts
      '/api': {
        target: 'http://localhost:8080',  //目标地址
        secure: false,
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ''),  //路径重写
      }
    }
  }
})
