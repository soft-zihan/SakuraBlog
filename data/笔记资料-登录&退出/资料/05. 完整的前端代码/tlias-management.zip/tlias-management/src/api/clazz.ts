import type { ClazzModel, ResultModel, PageResultModel } from '@/api/model/model'
import request from '@/utils/request'

//分页条件查询
export const queryPageApi = (begin: string, end: string, name: string, page: number, pageSize: number) => 
  request.get<any, PageResultModel>(`/clazzs?begin=${begin}&end=${end}&name=${name}&page=${page}&pageSize=${pageSize}`)

//新增班级
export const addApi = (clazz: ClazzModel) => request.post<any, ResultModel>('/clazzs', clazz)

//根据ID查询班级
export const queryInfoApi = (id: number) => request.get<any, ResultModel>(`/clazzs/${id}`)

//更新班级
export const updateApi = (clazz: ClazzModel) => request.put<any, ResultModel>(`/clazzs`, clazz)

//删除班级
export const deleteApi = (id: number) => request.delete<any, ResultModel>(`/clazzs/${id}`)

//查询全部班级信息
export const queryAllApi = () => request.get<any, ResultModel>('/clazzs/list') 
