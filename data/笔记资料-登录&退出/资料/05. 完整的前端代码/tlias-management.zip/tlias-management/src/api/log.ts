import type { PageResultModel } from '@/api/model/model'
import request from '@/utils/request'

//分页条件查询
export const queryPageApi = (page: number, pageSize: number) => request.get<any, PageResultModel>(`/log/page?page=${page}&pageSize=${pageSize}`)
