import type { StuModel, ResultModel, PageResultModel } from '@/api/model/model'
import request from '@/utils/request'

//分页条件查询
export const queryPageApi = (clazzId: string, degree: string, name: string, page: number, pageSize: number) => 
  request.get<any, PageResultModel>(`/students?clazzId=${clazzId}&degree=${degree}&name=${name}&page=${page}&pageSize=${pageSize}`)

//新增学生
export const addApi = (stu: StuModel) => request.post<any, ResultModel>('/students', stu)

//根据ID查询学生
export const queryInfoApi = (id: number) => request.get<any, ResultModel>(`/students/${id}`)

//修改学生
export const updateApi = (stu: StuModel) => request.put<any, ResultModel>(`/students`, stu)

//删除学生
export const deleteApi = (ids: string) => request.delete<any, ResultModel>(`/students/${ids}`)

//违纪处理
export const handleViolationApi = (id: any, score: any) => request.put<any, ResultModel>(`/students/violation/${id}/${score}`) 
