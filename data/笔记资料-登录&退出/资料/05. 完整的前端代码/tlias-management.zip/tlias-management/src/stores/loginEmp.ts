import { ref } from 'vue'
import { defineStore } from 'pinia'
import {type LoginInfo} from '@/api/model/model'

export const useLoginEmpStore = defineStore('loginEmp', () => {
  const loginEmp = ref<LoginInfo>({})
  const setLoginEmp = (emp: LoginInfo) => { //存入
    loginEmp.value = emp;
  }
  const getLoginEmp = () => { //获取
    return loginEmp.value;
  }
  const clearLoginEmp = () => { //清除
    loginEmp.value = {}
  }
  return { loginEmp, setLoginEmp, getLoginEmp, clearLoginEmp }
}, {persist: true})
