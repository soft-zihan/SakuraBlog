<script lang="ts" setup>

</script>

<template>
  <img src="../../assets/index.png">
</template>

<style scoped>

</style>