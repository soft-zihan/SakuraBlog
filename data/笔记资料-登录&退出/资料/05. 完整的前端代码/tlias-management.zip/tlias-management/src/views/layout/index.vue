<script lang="ts" setup>
  import { ref } from 'vue'
  import { ElMessage, ElMessageBox } from 'element-plus' 
  import { useRouter } from 'vue-router'
  import { useLoginEmpStore } from '@/stores/loginEmp'

  const loginName = ref()

  const router = useRouter()
  const loginStore = useLoginEmpStore();
  loginName.value = loginStore.getLoginEmp().name;

  //退出 
  const logout = () => {
    ElMessageBox.confirm('您确认退出登录吗?' , '退出登录', {confirmButtonText:'确认', cancelButtonText:'取消', type:'warning'})
    .then(async () => {
      loginStore.clearLoginEmp();
      router.push('/login')
      ElMessage.success('退出成功')
    }).catch(() => {
      ElMessage.info('取消退出')
    })
  }
</script>

<template>
  <div class="common-layout">
    <el-container>
      <!-- Header 头部区域 -->
      <el-header class="header">
        <span id="title">
          Tlias智能学习辅助系统
        </span>

        <span id="right_tool">
          <a href="/changePassword">
            <el-icon>
              <Edit />
            </el-icon> 修改密码 &nbsp;&nbsp;|&nbsp;&nbsp;
          </a>
          <a href="javascript:void(0)" @click="logout">
            <el-icon>
              <SwitchButton />
            </el-icon> 退出登录【{{loginName}}】
          </a>
        </span>
      </el-header>
      


      <!-- 左侧菜单及右侧主区域 -->
      <el-container>
        <!-- 左侧菜单 -->
        <el-aside width="200px" class="aside">
          <el-scrollbar>
            <el-menu router>
              <el-menu-item index="/index">
                <el-icon><Promotion /></el-icon> 首页
              </el-menu-item>

              <el-sub-menu index="/manage">
                <template #title>
                  <el-icon><Menu /></el-icon> 班级学员管理
                </template>
                <el-menu-item index="/clazz">
                  <el-icon><HomeFilled /></el-icon>班级管理
                </el-menu-item>
                <el-menu-item index="/stu">
                  <el-icon><UserFilled /></el-icon>学员管理
                </el-menu-item>
              </el-sub-menu>

              <el-sub-menu index="/system">
                <template #title>
                  <el-icon><Tools /></el-icon>系统信息管理
                </template>
                <el-menu-item index="/dept">
                  <el-icon><HelpFilled /></el-icon>部门管理
                </el-menu-item>
                <el-menu-item index="/emp">
                  <el-icon><Avatar /></el-icon>员工管理
                </el-menu-item>
              </el-sub-menu>

              <el-sub-menu index="/report">
                <template #title>
                  <el-icon><Histogram /></el-icon>数据统计管理
                </template>
                <el-menu-item index="/empReport">
                  <el-icon><InfoFilled /></el-icon>员工信息统计
                </el-menu-item>
                <el-menu-item index="/stuReport">
                  <el-icon><Share /></el-icon>学员信息统计
                </el-menu-item>
                <el-menu-item index="/log">
                  <el-icon><Document /></el-icon>日志信息统计
                </el-menu-item>
              </el-sub-menu>
            </el-menu>
          </el-scrollbar>
        </el-aside>
        
        <!-- 右侧主区域 -->
        <el-main>
          <!-- 动态展示选中菜单对应的组件 -->
          <!-- <IndexView></IndexView> -->
          <RouterView></RouterView>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<style scoped>
.header {
  /* background-color: #474ebf; */
  background-image: linear-gradient(to right, #6947bf, #8753c9, #a260d2, #bc6edc, #d57de5);
}

#title {
  font-size: 40px;
  font-weight: bold;
  font-family: 楷体;
  color: white;
  line-height: 60px;
}

#right_tool {
  float: right;
  line-height: 60px;
}

#right_tool > a {
  text-decoration: none;
  color: white;
}

.aside {
  width: 220px;
  border: 1px solid #ccc;
  height: 690px;
}
</style>