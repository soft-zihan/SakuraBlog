import './assets/main.css'

import { createApp } from 'vue'
import { createPinia } from 'pinia' //pinia
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate' //pinia的持久化插件

import App from './App.vue'
import router from './router'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import zhCn from 'element-plus/dist/locale/zh-cn.mjs' //引入国际化配置, 选择中文
import * as ElementPlusIconsVue from '@element-plus/icons-vue' //引入icon

const app = createApp(App)

app.use(createPinia().use(piniaPluginPersistedstate))
app.use(router)
app.use(ElementPlus, { locale: zhCn })

for (const [key, component] of Object.entries(ElementPlusIconsVue)) { //全局注册
  app.component(key, component)
}

app.mount('#app')
