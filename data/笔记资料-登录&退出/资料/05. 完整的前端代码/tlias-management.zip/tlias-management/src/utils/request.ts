import axios from 'axios'
import router from '@/router'
import { useLoginEmpStore } from '@/stores/loginEmp'
import { ElMessage } from 'element-plus' 

const loginStore = useLoginEmpStore();

//创建axios实例对象
const request = axios.create({
  baseURL: '/api',
  timeout: 600000
})

// axios请求拦截器
request.interceptors.request.use(
  config => {
    let loginInfo = loginStore.getLoginEmp(); //获取登录信息中的token令牌, 每一次请求的时候都将令牌携带过去.
    if(loginInfo && loginInfo.token){
      config.headers['token'] = loginInfo.token;
    }
    return config;
  },
  error => {
    console.log(error)
    return Promise.reject(error)
  }
)

//axios的响应 response 拦截器
request.interceptors.response.use(
  (response) => { //成功回调
    return response.data
  },
  (error) => { //失败回调
    console.log('error: ' + error)
    let { message } = error;
    if (message.includes('401')) {
      ElMessage.error('会话超时,请重新登录')
      router.push('/login')
    }else {
      ElMessage.error('系统接口访问异常')
    }
    return Promise.reject(error)
  }
)

export default request