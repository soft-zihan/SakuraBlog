<script setup lang="ts">

</script>

<template>
  <h1>Tlias 智能学习辅助系统</h1>
</template>

<style scoped>

</style>
